//file : msel.cpp

#include "../Sel/sel.h"

int main ()
{
    point P(2,3);
    sel<char> S(P,'A');


}
